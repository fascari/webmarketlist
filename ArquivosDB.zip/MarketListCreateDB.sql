SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0;
SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0;
SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='TRADITIONAL,ALLOW_INVALID_DATES';

DROP SCHEMA IF EXISTS `marketlist` ;
CREATE SCHEMA IF NOT EXISTS `marketlist` ;
USE `marketlist` ;

-- -----------------------------------------------------
-- Table `marketlist`.`Produtos`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketlist`.`Produtos` ;

CREATE TABLE IF NOT EXISTS `marketlist`.`Produtos` (
  `idProdutos` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(200) NOT NULL,
  `imagem` BLOB NULL,
  PRIMARY KEY (`idProdutos`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `marketlist`.`Supermercados`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketlist`.`Supermercados` ;

CREATE TABLE IF NOT EXISTS `marketlist`.`Supermercados` (
  `idSupermercados` INT NOT NULL AUTO_INCREMENT,
  `nome` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`idSupermercados`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `marketlist`.`ListaCompras`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketlist`.`ListaCompras` ;

CREATE TABLE IF NOT EXISTS `marketlist`.`ListaCompras` (
  `idListaCompras` INT NOT NULL AUTO_INCREMENT,
  `descricao` VARCHAR(200) NOT NULL,
  PRIMARY KEY (`idListaCompras`))
ENGINE = InnoDB;


-- -----------------------------------------------------
-- Table `marketlist`.`ItensListaCompras`
-- -----------------------------------------------------
DROP TABLE IF EXISTS `marketlist`.`ItensListaCompras` ;

CREATE TABLE IF NOT EXISTS `marketlist`.`ItensListaCompras` (
  `idListaCompras` INT NOT NULL,
  `idProdutos` INT NOT NULL,
  `idSupermercados` INT NULL,
  `quantidade` INT NOT NULL,
  `valor` DECIMAL(12,2) NOT NULL,
  `comprado` CHAR(1) NOT NULL DEFAULT 'N',
  PRIMARY KEY (`idListaCompras`, `idProdutos`),
  INDEX `fk_ItensListaCompras_ListaCompras_idx` (`idListaCompras` ASC),
  INDEX `fk_ItensListaCompras_Produtos1_idx` (`idProdutos` ASC),
  INDEX `fk_ItensListaCompras_Supermercados1_idx` (`idSupermercados` ASC),
  CONSTRAINT `fk_ItensListaCompras_ListaCompras`
    FOREIGN KEY (`idListaCompras`)
    REFERENCES `marketlist`.`ListaCompras` (`idListaCompras`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,
  CONSTRAINT `fk_ItensListaCompras_Produtos`
    FOREIGN KEY (`idProdutos`)
    REFERENCES `marketlist`.`Produtos` (`idProdutos`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE,
  CONSTRAINT `fk_ItensListaCompras_Supermercados`
    FOREIGN KEY (`idSupermercados`)
    REFERENCES `marketlist`.`Supermercados` (`idSupermercados`)
    ON DELETE RESTRICT
    ON UPDATE CASCADE)
ENGINE = InnoDB;


SET SQL_MODE=@OLD_SQL_MODE;
SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS;
SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS;
